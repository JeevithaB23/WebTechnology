let Mcdata=[
    {
        imgs:"https://th.bing.com/th/id/OIP.CIXgAzHsqpTS7emsavvyvgHaE5?w=257&h=180&c=7&r=0&o=5&dpr=1.4&pid=1.7",
       title :"Wanted",
        watch:"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"car"
    },
    {
        imgs:"https://th.bing.com/th/id/OIP.Yj5lrOKH66ThWVXZZ0lxCwHaE6?w=246&h=180&c=7&r=0&o=5&dpr=1.4&pid=1.7",
       title :"Wanted",
        watch:"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"car"
    },
    {
        imgs:"https://th.bing.com/th/id/OIP.jBpk4CzISQQbs3wtetEYCwHaE8?w=281&h=188&c=7&r=0&o=5&dpr=1.4&pid=1.7",
        title:"PK",
        watch:"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"car"
    },
    {
        imgs:"https://www.bing.com/images/search?view=detailV2&ccid=iIcO7p8u&id=BBD5F477D37428FD72537E720B2DA3024AC831F2&thid=OIP.iIcO7p8uDDn8n6Ma9a2CFgHaFj&mediaurl=https%3a%2f%2ffilmfare.wwmindia.com%2fcontent%2f2020%2faug%2fsalmankhan21596958977.jpg&exph=900&expw=1200&q=salman+khan&simid=608049262596990748&FORM=IRPRST&ck=50994BD95F0D0742A04999D170E90353&selectedIndex=2&itb=0",
        title:"Pathan",
        watch:"https://www.bing.com/ck/a?!&&p=e92fb8d949233e78JmltdHM9MTcxODIzNjgwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0Mw&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=top+10+bollywood+movies&u=a1aHR0cHM6Ly93d3cuaW1kYi5jb20vbGlzdC9sczA1MTU5NDQ5Ni8&ntb=1",
        Aname:"car"
    },
]

export default Mcdata