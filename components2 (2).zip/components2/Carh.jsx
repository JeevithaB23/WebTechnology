import React from 'react'

const carh=()=>{
    return(
        <div>
        <div>
            <h1 className="head">Top 50 best Cars</h1>
        </div>
        </div>
    )
}
export default carh