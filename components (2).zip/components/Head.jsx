import React from 'react';

// const Head=()=>{
//     return(
//         <>
//         <h1 contentEditable="true">Welcome</h1>
//         <h1 contentEditable="true">Editable</h1>
//         </>
//     );
// }


const movieh=()=>{
    return(
        <div>
        <div>
            <h1 className="head">TOP 50 CARS</h1>
        </div>
        </div>
    )
}
export default movieh


